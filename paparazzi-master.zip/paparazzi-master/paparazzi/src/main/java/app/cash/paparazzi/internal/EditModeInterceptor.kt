package app.cash.paparazzi.internal

object EditModeInterceptor {
  @JvmStatic
  fun intercept(): Boolean = false
}